# No Wikipedia Search

<!-- chrome and firefox shields go here -->

## Description

Adds buttons to toggle auto-clicker and golden cookie auto-clicker to Cookie Clicker. The auto-clicker clicks every 5ms and the golden cookie auto-clicker checks for golden cookies to click every 50ms.

## Why?

I need to get more cookies but I can't keep clicking while I'm at work! Having to write the intervals in the console each time the page loaded was becoming a pain, so here are some buttons.

## Installation

<!-- chrome link here -->
<!-- firefox link here -->

Download the .zip file from GitHub then install in your browser of choice. Tested and confirmed to work in Firefox.

<!-- ## License -->
<!-- do I need a license? -->
